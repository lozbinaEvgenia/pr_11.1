﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Figure_Calculate
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        public class Figure
        {
            public double widthR;
            public double heightR;
            public double s1;
            public double s2;
            public double s3;
            public double radius;
            public double CalculateAreaC()
            {

                return Math.PI*radius * radius;
            }
            public double CalculatePerimeterC()
            {
                return 2 * Math.PI * radius;
            }
            public double CalculateAreaR()
            {
                 
                return widthR*heightR;
            }
                public  double CalculatePerimeterR()
                {
                    return 2 * (widthR + heightR);
                }

            public double CalculateAreaT()
            {
                double s = (s1 + s2 + s3) / 2;
                return Math.Sqrt(s * (s - s1) * (s - s2) * (s - s3));
                
            }
            public double CalculatePerimetrT()
            {
               return s1+s2+s3;
            }
        }
      

        private void Form1_Load(object sender, EventArgs e)
        {


        }

        private void button1_Click(object sender, EventArgs e)
        {

            Figure rectangle1 = new Figure();
            rectangle1.widthR = (double)(numericUpDown1.Value);
            rectangle1.heightR= (double)(numericUpDown2.Value);
            MessageBox.Show(string.Format("Площадь прямоугольника: {0}\nПериметр прямоугольника:{1}", rectangle1.CalculateAreaR(), rectangle1.CalculatePerimeterR()));


        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Figure triangle1=new Figure();
            triangle1.s1= (double)(numericUpDown3.Value);
            triangle1.s2 = (double)(numericUpDown4.Value);
            triangle1.s3= (double)(numericUpDown5.Value);
            MessageBox.Show(string.Format("Площадь треугольника:{0}\nПериметр треугольника: {1}", Math.Round(triangle1.CalculateAreaT(),2), triangle1.CalculatePerimetrT()));

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Figure cercle=new Figure();
            cercle.radius = (double)(numericUpDown6.Value);
            MessageBox.Show(string.Format("Площадь круга: {0}\nПериметр круга: {1}", Math.Round(cercle.CalculateAreaC(),2), Math.Round(cercle.CalculatePerimeterC(),2)));

        }
    }
}
